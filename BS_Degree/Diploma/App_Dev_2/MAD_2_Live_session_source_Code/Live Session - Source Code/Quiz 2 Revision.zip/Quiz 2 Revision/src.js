// Topics

// Week 5
// Fetch API
// Event loop, promises
// async/await, .then/.catch/.finally
// Lifecycle hooks:
// Error handling:
// Network errors

// Week 6
// Single File Components (SFC)
// Form validation
// Persistent storage
// <router-link>, <router-view>, route creation
// local storage, session storage

// Week 7
// Store, mutations, actions, dispatch

// SPA (Single Page Application), PWA (theory)
// Dynamic routes using : binding
// programmatic navigation

// Week 8
// REST and SOAP APIs
// Best practices in API design

//plural noun
// discourage verbs in end point

// api/users/
// GET -> retrieve data
// POST -> add new data
// PUT, DELETE, PATCH

// Authentication:

// Session-based
// JWT
// OAuth

// Promises
// Vue + Flask Integration

// Promise().then().catch().finally()
// async fun -> await

// const promise = new Promise((res, rej) => {
//   // res("success"); // promise resolved
//   rej("fail"); // promise rejected
//   // throw new Error("error");
// });

// promise
//   .then(
//     (sucess) => {
//       console.log(sucess);
//     },
//     (rejection) => {
//       console.log("2nd then");
//       console.log(rejection);
//     }
//   )
//   .catch(() => console.log(".catch running"))
//   .finally(() => console.log("finally running"));

// prom1 = new Promise((res, rej) => {
//   rej("rejected");
// });

// prom2 = new Promise((res, rej) => {
//   setTimeout(() => {
//     res("success");
//   }, 2000);
// });

// Promise.all([prom1, prom2])
//   .then((result) => {
//     console.log(result);
//   })
//   .catch(() => {
//     console.log("catch all");
//   }); // when all promises complete then execute .then

// Promise.any([prom1, prom2]).then((result) => console.log(result)); // if any promise complete move on

// async function test_promises() {
//   const promises = await Promise.all([prom1, prom2]);
//   console.log("promises completed");
// }

// const p1 = new Promise((x, y) => {
//   setTimeout(() => x("A"), 100);
// });

// const p2 = new Promise((resolve, reject) => {
//   setTimeout(() => reject("B"), 100);
// });

// const p3 = new Promise((resolve, reject) => {
//   setTimeout(() => resolve("C"), 150);
// });

// Promise.any([p1, p2, p3])
//   .then((value) => console.log(value))
//   .catch((error) => console.log("error:" + error));

// What will be the output of the above program?

// A correct
// B
// C
// The catch block will execute

// async function hello(){
//   await Promise.resolve("hello");
// }

// await Promise.resolve("hello");

// async function asyncFunc() {
//   try {
//     console.log("Inside async func before await");
//     const result1 = await Promise.resolve("Start");
//     console.log(result1);

//     const result2 = await new Promise((resolve, reject) => {
//       setTimeout(() => reject("Error"), 100);
//     });

//     console.log(result2);
//   } catch (error) {
//     console.log("Caught:", error);
//   }

//   return "End";
// }

// console.log("code start");
// asyncFunc()
//   .then((result) => console.log(result))
//   .catch((err) => console.log(err));
// console.log("code end");

// What will be the output of the program?

// Start, Caught: Error, End
// Start, End, Caught: Error
// Caught: Error, Start, End
// Start, Error, End

// lifecycle

// <div id="app"></div>

// <script>
//     new Vue({
//         el: '#app',
//         data() {
//             return {
//                 message: 'Hello'
//             };
//         },
//         beforeCreate() {
//             console.log('Before Create: ' + this.message);
//             this.message = 'Before Create';
//         },
//         mounted() {
//             this.message = 'Mounted';
//             console.log('Mounted: ' + this.message);
//         },
//         template: `
//             <div>
//                 <p>{{ message }}</p>
//             </div>
//         `
//     });
// </script>

// What will be printed in the browser console ?
// `Before Create: Before Create` and `Mounted: Hello`
// `Before Create: undefined` and `Mounted: Hello`
// `Before Create: Hello` and `Mounted: Mounted`
// `Before Create: undefined` and `Mounted: Mounted`

// Fetch call

// const unfulfilled = fetch("https://jsonplaceholder.typicode.com/users")
//   .then((res) => res.json())
//   .then((data) => {
//     data.forEach((user) => console.log(user.name));
//   })
//   .catch();

// // for (i = 0; i < 1000000;) try out a large loop

// console.log(unfulfilled); // sync

// SFC

// .vue files,

// <template>

// </template>

// <script>

// </script>

// <style>

// </style>

// persistent storage

// localStorage
// sessionStorage

// indexedDB
// cookies

// obj = {
//   userName: "aditya",
//   rollNo: "101",
//   sayHello() {
//     console.log(this.userName + "hello");
//   },
// };

// localStorage.setItem("key1", 10);
// sessionStorage.setItem("key2", 20);

// localStorage.setItem("user", JSON.stringify(obj));

// user = JSON.parse(localStorage.getItem("user"));

// console.log(user.userName);

// localStorage.clear();

// const routes = [
//     {path: '/', component : Home},
//     {path: '/about', component : About},
//     {path: '/dashboard', component: Dashboard, children : [
//         {path: '/admin', component: Admin},
//         {path: '/student', component: Student}
//     ]},
//     {path: "*", component: Error}
// ]

// template: `
// <router-view />
// `

// Dashboard:

// <router-view />
// // / -> Home

// /dashboard ?? -> Error ??

// /dashboard/admin -> Dashboard & Admin

// function addItemToCart(item) {
//   let cart = JSON.parse(localStorage.getItem("cart")) || []; // [], ['Laptop']
//   cart.push(item); // ["Laptop", "Laptop", "Laptop"]
//   localStorage.setItem("cart", JSON.stringify(cart)); // local -> cart: ["Laptop", "Laptop"]
// }

// function getCartItems() {
//   return JSON.parse(localStorage.getItem("cart")) || [];
// }

// addItemToCart({ id: 1, name: "Laptop" }.name); // "Laptop"
// console.log(getCartItems());
// ["Laptop", "Laptop", "Laptop"];

// The above code is initially loaded on the browser and
// then the browser is refreshed two times. What will be
// the final output?

// [MCQ: 3 points]

// []
// ['Laptop', ‘Laptop’, ‘Laptop’]
// [{ id: 1, name: 'Laptop' }]
// [undefined]

// What's the issue with this Vuex mutation? Assuming this mutation is part of
// vuex store.

// mutations: {
//   updateUser(state, userData) {
//     state.user = userData
//     state.lastUpdated = Date.now()
//     if (userData.role === 'admin') {
//       fetchAdminData().then(data => {
//         state.adminData = data
//       })
//     }
//   }
// }

// Multiple state changes in one mutation
// Async operation in mutation
// Direct state mutation
// Both A and B

// new Promise((res, rej) => {
//   console.log("hi from promise");
//   res("success");
//   console.log("after res");
// }).then((r) => console.log(r));

// console.log("end");
