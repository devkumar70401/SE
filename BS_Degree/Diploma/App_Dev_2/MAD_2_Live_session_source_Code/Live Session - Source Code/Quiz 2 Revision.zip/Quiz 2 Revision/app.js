const About = {
  template: `<h1>About {{data}}  
  <button @click="$emit('button-clicked')">Click</button>
  </h1>`,
  props: ["data"],
  methods: {},
};

const Home = {
  template: `<div> <h1>Home</h1>
  
  <button @click="print_console">Log</button>
  <About data="hello" @button-clicked="call_a_function"/>
  <About data="Hi"/>
  <About data="wow"/>
  </div>`,
  data() {
    return {};
  },
  methods: {
    print_console() {
      this.$store.commit("changeState1");
      this.$store.dispatch("triggerState1");
      console.log(this.$store.state.abc);
    },
    call_a_function() {
      console.log("child has button clicked");
    },
  },
  components: {
    About,
  },
};
const Dashboard = { template: "<h1>Dashboard <router-view />  </h1>" };
const Error = {
  template:
    "<h1>Error <router-link to='/dashboard/student/1890'>Go Do</router-link> </h1>",
};
const Admin = { template: "<h1>Admin </h1>" };
const Student = {
  template: "<h1>Student <h3>{{$route.params.id}}</h3> </h1>",
};
const Random = { template: "<h1>Random </h1>" };

const routes = [
  { path: "/", component: Home },
  { path: "/about", component: About },
  {
    path: "/dashboard",
    component: Dashboard,
    children: [
      { path: "", component: Random },
      { path: "admin", component: Admin },
      { path: "student/:id", component: Student },
    ],
  },
  { path: "*", component: Error },
];

const router = new VueRouter({ routes });

// / -> Home

// /dashboard ?? -> Random ??

// /dashboard/admin -> Dashboard & Admin

// // vuex

// // state -> data
// // getter -> like computed properties
// // mutations -> change state  (commit keyword), sync
// // actions -> commit mutations (dispatch keyword), async

const store = new Vuex.Store({
  state: {
    abc: 10,
    bcd: 11,
  },
  getters: {
    returnModifiedState(state) {
      return state.bcd + "%%%";
    },
  },
  mutations: {
    changeState1(state) {
      state.abc += 1;
    },
  },
  actions: {
    triggerState1(context) {
      setTimeout(() => context.commit("changeState1"), 100);
    },
  },
});

new Vue({
  el: "#app",
  template: `<router-view />`,
  router: router,
  store: store,
});

// inside vue components
// this.$store.commit()

// new Vue({
//   el: "#app",
//   template: `<div>
//         <router-view />
//     </div>`,
//   router,
//   store,
// });

// Vue.component("child", {
//   template: "<div>{{ message }}</div>",
//   data() {
//     return {
//       message: "Initial",
//     };
//   },
//   mounted() {
//     setTimeout(() => {
//       this.message = "Updated in child";
//     }, 0);
//   },
// });

// new Vue({
//   template: `<div> <child ref="child"/> </div>`,
//   el: "#app",
//   mounted() {
//     setTimeout(() => {
//       this.$refs.child.message = "Updated in parent";
//     }, 200);
//   },
//   methods: {
//     updateParent() {
//       this.$refs.child.message = "Button clicked";
//     },
//   },
// });
